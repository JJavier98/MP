#include <iostream>
using namespace std;
int main()
{
    cout << "Nombre" << "Apellidos" << "Edad" << "Estado" << endl;
    cout << "Javier" << "Moreno" << 20 << "S" << endl;
    cout << "Juan" << "Espejo" << 8 << "S" << endl;
    cout << "Antonio" << "Caballero" << 53 << "C" << endl;
    cout << "Jose" << "Cano" << 27 << "C" << endl;

    cout << endl;

    cout << 123.456 << 26.467872 << 876.3876 << endl;
    cout << 17.26734 << 0.22 << 18972.1 << endl;
    cout << 456.5 << 2897.0 << 2832.3 << endl;
}
