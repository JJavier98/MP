#include <iostream>
using namespace std;

int main(){
	cout << sizeof(char);
	cout << "\n";
	cout << sizeof(short int);
	cout << "\n";
	cout << sizeof(int);
	cout << "\n";
	cout << sizeof(long int);
	cout << "\n";
	cout << sizeof(float);
	cout << "\n";
	cout << sizeof(double);
	cout << "\n";
	cout << sizeof(long double);
	cout << "\n";
	cout << sizeof(long long int);
	cout << "\n";
}
