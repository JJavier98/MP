#ifndef _AVANZAR_H
#define _AVANZAR_H
#include <fstream>
#include <iostream>

void Avanzar(std::istream& is);

#endif