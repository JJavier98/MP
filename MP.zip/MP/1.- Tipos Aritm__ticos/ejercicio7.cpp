#include <iostream>

using namespace std;

int main()
{
  cout << (4<1<5?"Ordenados":"Desordenados") << endl;
}
