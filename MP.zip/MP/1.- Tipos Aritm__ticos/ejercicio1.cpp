#include <iostream>
using namespace std;

int main(){
	cout << sizeof(char) << endl;
	cout << sizeof(short int) << endl;
	cout << sizeof(int) << endl;
	cout << sizeof(long int) << endl;
	cout << sizeof(float) << endl;
	cout << sizeof(double) << endl;
	cout << sizeof(long double) << endl;
	cout << sizeof(long long int) << endl;
}
